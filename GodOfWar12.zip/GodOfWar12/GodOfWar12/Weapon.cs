﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodOfWar12
{
    internal class Weapon
    {

        public static List<Weapon> weapons = new List<Weapon>();

        public string name;
        public int damage;


        public Weapon(string name, int damage)
        {
            this.name = name;
            this.damage = damage;

        }
        public static Weapon Fist = new Weapon("Pěsti", 5);
        public static Weapon Axe = new Weapon("Sekera", 15);
        public static Weapon Sword = new Weapon("Meč", 20);
        public static Weapon Spear = new Weapon("Kopí", 45);
        public static Weapon ElderSword = new Weapon("Starodávný meč", 65);


    }
}
