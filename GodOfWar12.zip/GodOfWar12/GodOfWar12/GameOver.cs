﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GodOfWar12
{
    public partial class GameOver : Form
    {
        public GameOver()
        {
            InitializeComponent();
            label2.Text = "Počet nalezených předmětů: " + Player.ammountOfItems;
            label3.Text = "Tvůj level: " + Player.level;
            label4.Text = "Počet zabitých nepřátel: " + Player.ammoutOfKills;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
