﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodOfWar12
{
    internal class Fight
    {
        Random rd = new Random();

        public void Combat(Enemy enemy)
        {
            int enemyHp = enemy.ehealth;
            int enemyDam = enemy.edamage;
            while (Player.hp >= 1 && enemyHp >= 1)
            {
                Player.hp -= (enemyDam - Player.resistance);
                enemyHp -= (enemy.eresistance + Player.Attack());
            }
            if (Player.hp >= 1)
            {
                FightWin(enemy);
            }
            else
            {
                FightLost();
            }

        }
        public void FightWin(Enemy enemy)
        {
            Player.ammoutOfKills++;
            Player.xp += enemy.eXpDrop;
            Player.wood += 5;
            ItemDrop();
            if (enemy == Enemy.deer || enemy == Enemy.boar)
            {
                Player.meat += 2;
            }
            if (enemy == Enemy.treeMan)
            {
                int weaponChance = rd.Next(1, 21);
                if (8<weaponChance)
                {
                    Player.weapon = Weapon.ElderSword;
                    Player.ammountOfItems++;
                }
            
            }
            if (enemy  == Enemy.typoon)
            {
                
            }
        }

        public void ItemDrop()
        {
            int weaponChance = rd.Next(1, 101);
            if (25 < weaponChance)
            {
                Player.weapon = Weapon.Axe;
                Player.ammountOfItems++;
            }
            else if (13 < weaponChance)
            {
                Player.weapon = Weapon.Sword;
                Player.ammountOfItems++;
            }
            else if (8 < weaponChance)
            {
                Player.weapon = Weapon.Spear;
                Player.ammountOfItems++;

            }
          
            {

            }

            int armorChance = rd.Next(1, 101);
            if (25 < armorChance)
            {
                Player.resistance += Armor.Leather.resistance;
                Player.armor = Armor.Leather;
                Player.ammountOfItems++;
            }
            else if (13 < armorChance)
            {
                Player.resistance += Armor.Silver.resistance;
                Player.armor = Armor.Silver;
                Player.ammountOfItems++;
            }
            else if (8 < armorChance)
            {
                Player.resistance += Armor.Diamond.resistance;
                Player.armor = Armor.Diamond;
                Player.ammountOfItems++;
            }
        }

        public void FightLost()
        {
            GameOver ChildForm = new GameOver();
            ChildForm.Show();
            

        }
    }
}
