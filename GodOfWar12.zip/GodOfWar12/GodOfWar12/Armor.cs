﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodOfWar12
{
    internal class Armor
    {


        public string name;
        public int resistance;
        public int hp;

        public Armor(string name, int resistance, int hp)
        {
            this.name = name;
            this.resistance = resistance;
            this.hp = hp;

        }
        public static Armor Nothing = new Armor("Nic", 0, 0);
        public static Armor Leather = new Armor("Koženné", 3, 1);
        public static Armor Silver = new Armor("Stříbrnné", 9, 1);
        public static Armor Diamond = new Armor("Diamantové", 15, 5);
    }
}
