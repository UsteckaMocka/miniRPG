﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodOfWar12
{
    internal class Player
    {
        public static int level = 1;
        public static int hp = 205;
        public static int resistance = 5;
        public static int damage = 25;
        public static int xp = 0;
        public static int attributePoints = 0;
        public static int wood;
        public static int meat;

        public static Weapon weapon = null;
        public static Armor armor = null;

        public static int ammountOfItems;
        public static int ammoutOfKills;

        public static int Attack()
        {
            return weapon == null ? damage : damage + weapon.damage;
        }
        public static int defense()
        {
            return armor == null ? resistance : resistance + armor.resistance;
        }

    }
}
