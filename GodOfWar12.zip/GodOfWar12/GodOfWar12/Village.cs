﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GodOfWar12
{
    public partial class Village : Form
    {
        public List<PictureBox> enemyPic = new List<PictureBox>();
        Random rd = new Random();

        public Village()
        {
            InitializeComponent();

            this.Width = int.MaxValue;
            this.Height = 842;
            AddEnemyToList();
           fireplacetimer.Stop();
        }


        public void AddEnemyToList()
        {
            enemyPic.Add(pictureBox1);
            enemyPic.Add(pictureBox2);
            enemyPic.Add(pictureBox3);
            enemyPic.Add(pictureBox4);
            enemyPic.Add(pictureBox5);
            enemyPic.Add(pictureBox6);
            enemyPic.Add(pictureBox7);
            enemyPic.Add(pictureBox8);
            enemyPic.Add(pictureBox9);
            enemyPic.Add(pictureBox10);
            enemyPic.Add(pictureBox11);
            enemyPic.Add(pictureBox12);
            enemyPic.Add(pictureBox13);
            enemyPic.Add(pictureBox14);
            enemyPic.Add(pictureBox15);
            enemyPic.Add(pictureBox16);
            enemyPic.Add(pictureBox17);
            enemyPic.Add(pictureBox18);
            enemyPic.Add(pictureBox19);

        }
        private void fireplacetimer_Tick(object sender, EventArgs e)
        {
             
        }
       public static void Fireplace()
        {
            MessageBox.Show("Našel si ohniště");

            while (Player.wood >= 1)
            {
                Player.wood--;
                Player.hp += 2;
                while (Player.meat >=1)
                {
                    Player.meat--;
                    Player.hp += 5;
                }

            }

        }
      
        //movement
        private void Village_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
            {
                float changetofindfireplace = rd.Next(101);
                if (changetofindfireplace <= 0.001)
                {
                    Fireplace();
                }
                foreach (PictureBox item in enemyPic.ToList())
              {
                   
                    item.Left -= 40;
                    
                   
              }
            }


            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
            {
                foreach (PictureBox item in enemyPic.ToList())
                {
                    item.Left += 20;
                }
            }

            if (e.KeyCode == Keys.Tab)
            {
                attributemenu.Show();
            }
           
        }


        void AdjustEnemy(Enemy enemy, PictureBox pc)
        {
            Fight fight = new Fight();
            fight.Combat(enemy);
            this.Controls.Remove(pc);
            pc.Location = new Point(0, 100000);
           
        }
        
        

        private void timer1_Tick(object sender, EventArgs e)
        {
        


            label1.Text = "Level :" + Player.level;
            label2.Text = "Životy :" + Player.hp;
            label3.Text = "Poškození :" + Player.Attack();
            label4.Text = "Obrana :" + Player.defense();
            label5.Text = "Máš " + Player.wood + " dřeva";
            label6.Text = "Máš " + Player.meat + " masa";
            label7.Text = "Máš " + Player.attributePoints + " bodů attributu";

            if (Player.ammoutOfKills == 19)
            {
                GameWin ChildForm = new GameWin();
                ChildForm.Show();
                this.Hide();
            }

            if (Player.xp >= 200)
            {

                Player.level++;
                Player.xp = 0;
                Player.attributePoints += 5;
                panel1.Show();
            }
            if (Player.attributePoints == 0)
            {
                panel1.Hide();
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox1.Bounds))
            {
                AdjustEnemy(Enemy.treeMan, pictureBox1);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox2.Bounds))
            {
                AdjustEnemy(Enemy.roman, pictureBox2);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox3.Bounds))
            {
                AdjustEnemy(Enemy.roman, pictureBox3);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox4.Bounds))
            {
                AdjustEnemy(Enemy.roman, pictureBox4);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox5.Bounds))
            {
                AdjustEnemy(Enemy.romanWithAxe, pictureBox5);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox6.Bounds))
            {
                AdjustEnemy(Enemy.romanWithSpear, pictureBox6);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox7.Bounds))
            {
                AdjustEnemy(Enemy.romanWithSpear, pictureBox7);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox8.Bounds))
            {
                AdjustEnemy(Enemy.treeMan, pictureBox8);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox9.Bounds))
            {
                AdjustEnemy(Enemy.romanWithSword, pictureBox9);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox10.Bounds))
            {
                AdjustEnemy(Enemy.romanWithSword, pictureBox10);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox11.Bounds))
            {
                AdjustEnemy(Enemy.romanWithSpear, pictureBox11);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox12.Bounds))
            {
                AdjustEnemy(Enemy.romanWithSword, pictureBox12);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox13.Bounds))
            {
                AdjustEnemy(Enemy.treeMan, pictureBox13);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox14.Bounds))
            {
                AdjustEnemy(Enemy.treeMan, pictureBox14);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox15.Bounds))
            {
                AdjustEnemy(Enemy.romanWithAxe, pictureBox15);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox16.Bounds))
            {
                AdjustEnemy(Enemy.treeMan, pictureBox16);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox17.Bounds)) ////////////////
            {
                AdjustEnemy(Enemy.typoon, pictureBox17);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox18.Bounds))
            {
                AdjustEnemy(Enemy.boar, pictureBox18);
            }
            if (playerpanel.Bounds.IntersectsWith(pictureBox19.Bounds))
            {
                AdjustEnemy(Enemy.deer, pictureBox19);
            }
        }

        private void Village_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                attributemenu.Hide();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (Player.attributePoints >= 1)
            {
                Player.hp += 20;
                Player.attributePoints--;
                label2.Text = "Životy :" + Player.hp;
                label7.Text = "Máš " + Player.attributePoints + " bodů";
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (Player.attributePoints >= 1)
            {
                Player.damage += 10;
                Player.attributePoints--;
                label3.Text = "Poškození :" + Player.Attack();
                label7.Text = "Máš " + Player.attributePoints + " bodů";

            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            if (Player.attributePoints >= 1)
            {
                Player.resistance += 5;
                Player.attributePoints--;
                label4.Text = "Obrana :" + Player.defense();
                label7.Text = "Máš " + Player.attributePoints + " bodů";

            }
        }

      
    }
}
