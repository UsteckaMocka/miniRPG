﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodOfWar12
{
    internal class Enemy
    {

        public static Random rd = new Random();
        public int edamage;
        public int eresistance;
        public int ehealth;
        public int elevel;
        public string ename;
        Weapon weapon;

        public int eXpDrop;




        public Enemy(int edamage, int eresistance, int ehealth, int elevel, string ename, int eXpDrop, Weapon weapon)
        {
            this.edamage = edamage;
            this.eresistance = eresistance;
            this.ehealth = ehealth;
            this.elevel = elevel;
            this.ename = ename;
            this.eXpDrop = eXpDrop;
            this.weapon = weapon;


        }


        public static Enemy roman = new Enemy(5, 5, 10, 5, "Hrdý říman", 20, Weapon.Fist);
        public static Enemy romanWithAxe = new Enemy(15, 10, 25, 10, "Říman se sekerou", 20, Weapon.Axe);
        public static Enemy romanWithSpear = new Enemy(15, 10, 25, 10, "Říman s kopím", 50, Weapon.Spear);
        public static Enemy romanWithSword = new Enemy(10, 15, 20, 7, "Říman s mečem", 35, Weapon.Sword);
        public static Enemy deer = new Enemy(0, 0, 20, 1, "Jelen", 10, Weapon.Fist);
        public static Enemy boar = new Enemy(1, 0, 50, 2, "Divocak", 10, Weapon.Fist);
        public static Enemy treeMan = new Enemy(20, 5, 40, 5, "Guardian of the Elder Sword", 100, Weapon.Sword);
        // public static Enemy ambusher = new Enemy(5, 5, 10, 5, "Baf more", 20, Weapon.Fist);
        public static Enemy typoon = new Enemy(50, 150, 500, 10, "Typolon the great", 5000, Weapon.ElderSword);

    }
}
